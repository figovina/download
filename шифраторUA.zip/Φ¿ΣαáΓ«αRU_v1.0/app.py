import keyw
keyword = keyw.Keyw()
keyword.setKey('')
exw = 'exit'
a = 1
b = 1
keywords = []
bad11 = '''' '''
bad12 = ' '
bad2 = '''"'''
bad1 = ''
bad3 = ''
key = ''
for c in bad11:
    if c == bad12:
        pass
    else:
        bad1 = c
#print('a %s a' % bad1)

print('ШИФРАТОР v1.0')

while True:
    print('напишите 1 если хотите зашифровать текст')
    print('напишите 2 если хотите розшифровать текст')
    print('напишите 3 если хотите сменить ключ')
    num = input()

    if num == bad3:
        pass
    elif int(num) == 1:
        a = 1
        print('напишите exit если хотите сменить режим')

        while a == 1:
            text1 = ''
            text = input()
            if text == exw:
                a = 0
            else:
                for b in text:
                    if b == bad1 or b == bad2:
                        pass
                    else:
                        text1 = text1 + b
                if text1 == bad3:
                    print('напишите exit если хотите сменить режим')
                else:
                    keyword.findKeys(text1, 0)

    elif int(num) == 2:
        b = 1
        print('напишите exit если хотите сменить режим')
        while b == 1:
            text = input()
            if text == exw:
                b = 0
            elif text == bad3:
                print('напишите exit если хотите сменить режим')
            else:
                exec('keywords = %s' % text)
                keyword.findText(keywords, 0)
    elif int(num) == 3:
        print('''напишите новый ключ
ВНИМАНИЕ: В КАЧЕСТВЕ КЛЮЧА ПРИНИАЮТСЯ ТОЛЬКО ЦИФРЫ И БУКВЫ АНГЛИЙСКОГО АЛФАВИТА,
ОСТАЛЬНЫЕ СИМВОЛЫ ИГНОРИРУЮТСЯ
текущий ключ: %s''' % key)
        key = input()
        keyword.setKey(key)
