import keyw
keyword = keyw.Keyw()
keyword.setKey('')
exw = 'exit'
a = 1
b = 1
keywords = []
bad11 = '''' '''
bad12 = ' '
bad2 = '''"'''
bad1 = ''
bad3 = ''
key = ''
for c in bad11:
    if c == bad12:
        pass
    else:
        bad1 = c


print('ШИФРАТОР v1.0')

while True:
    print('напишіть 1 якщо хочете зашифрувати текст')
    print('напишіть 2 якщо хочете розшифрувати текст')
    print('напишіть 3 якщо хочете змінити ключ')
    num = input()

    if num == bad3:
        pass
    elif int(num) == 1:
        a = 1
        print('напишіть exit якщо хочете змінити режим')

        while a == 1:
            text1 = ''
            text = input()
            if text == exw:
                a = 0
            else:
                for b in text:
                    if b == bad1 or b == bad2:
                        pass
                    else:
                        text1 = text1 + b
                if text1 == bad3:
                    print('напишіть exit якщо хочете змінити режим')
                else:
                    keyword.findKeys(text1, 0)

    elif int(num) == 2:
        b = 1
        print('напишіть exit якщо хочете змінити режим')
        while b == 1:
            text = input()
            if text == exw:
                b = 0
            elif text == bad3:
                print('напишіть exit якщо хочете змінити режим')
            else:
                exec('keywords = %s' % text)
                keyword.findText(keywords, 0)
    elif int(num) == 3:
        print('''напишіть новий ключ
УВАГА: В ЯКОСТІ КЛЮЧА ПРИЙМАЮТЬСЯ ЛИШЕ ЦИФРИ Й БУКВИ АНГЛІЙСЬКОГО АЛФАВІТУ,
ІНШІ СИМВОЛИ ІГНОРУЮТЬСЯ
  нинішій ключ: %s''' % key)
        key = input()
        keyword.setKey(key)
